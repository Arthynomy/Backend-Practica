const express = require('express')
const mongoose=require('mongoose')
const Tareas=require('./modelos/tareaModelo')
const app = express()
const port = 3000

app.use(express.json())

app.get('/mostrartareas', async(req, res) => {
    try{
        const tareas=await Tareas.find({})
        res.status(200).json(tareas)
    }catch(error){
        console.log(error.message)
        res.status(500).json({message:error.message})
    }
})

app.get('/mostrartarea/:id', async(req, res) => {
    try{
        const {id}=req.params
        const tareas=await Tareas.findById(id)
        res.status(200).json(tareas)
    }catch(error){
        console.log(error.message)
        res.status(500).json({message:error.message})
    }
})

app.post('/creartarea', async(req, res) => {
    try{
        const tareas=await Tareas.create(req.body)
        res.status(200).json(tareas)
    }catch(error){
        console.log(error.message)
        res.status(500).json({message:error.message})
    }
})

app.put('/editartarea/:id', async(req, res) =>{
    try{
        const{id}=req.params
        const tareas=await Tareas.findByIdAndUpdate(id,req.body)
        if(!tareas){
            return res.status(404).json({message:"ese id no existe"})
        }
        res.status(200).json(tareas)
    }catch(error){
        console.log(error.message)
        res.status(500).json({message:error.message})
    }
})

app.delete('/borrartarea/:id', async(req, res) => {
    try{
        const{id}=req.params
        const tareas=await Tareas.findByIdAndDelete(id)
        res.status(200).json(tareas)
    }catch(error){
        console.log(error.message)
        res.status(500).json({message:error.message})
    }
})


mongoose.set('strictQuery',false)
mongoose.connect('mongodb+srv://ch190117790:VpSQBZLTNC9enZKn@trabajoapi.fawzgoc.mongodb.net/Backend?retryWrites=true&w=majority')
.then(()=>{
    console.log("Conectado correctamente")
    app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
      })
})
.catch(()=>{
    console.log(error);
})