const mongoose=require('mongoose')

const tareasSchema= mongoose.Schema({
        Titulo:{
            type:String,
            required:[true,"Titulo requerido requerido"],
            default:['sin titulo']
        },
        Descripción:{
            type:String,
            required:[true,"descripcion requerida"],
            default:['sin descripción']
        },
        Status:{
            type:String,
            required:[true,"estado requerido"],
            default:['sin Status']
        },
        FechaDeEntrega:{
            type:String,
            required:[true,"espacio requerido"],
            default:['sin fecha']
        }, 
        Comentarios:{
            type:String,
            required:[true,"Comentario requerido"],
            default:['sin comentarios']
        },
        Responsable:{
            type:String,
            required:[true,"Responsable requerido"],
            default:['sin Responsble']
        }
    },
    {
        timestamps:true
    })
const Tareas=mongoose.model('Tareas',tareasSchema)
module.exports=Tareas